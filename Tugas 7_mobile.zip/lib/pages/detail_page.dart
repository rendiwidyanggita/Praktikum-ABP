import 'package:flutter/material.dart';

import '../models/devil_fruit.dart';
import 'favorite_form_page.dart';

class DetailPage extends StatelessWidget {
  const DetailPage({super.key, required this.fruit});

  final DevilFruit fruit;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(fruit.name)),
      body: Container(
        color: const Color(0xFF0B1D3A),
        child: ListView(
          padding: const EdgeInsets.fromLTRB(18, 18, 18, 24),
          children: [
            Hero(
              tag: fruit.image,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.asset(
                  fruit.image,
                  height: 220,
                  width: double.infinity,
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              fruit.name,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 14),
            _InfoPanel(fruit: fruit),
            const SizedBox(height: 18),
            const Text(
              'Kekuatan',
              style: TextStyle(
                color: Color(0xFFFFB547),
                fontSize: 18,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              fruit.description,
              style: const TextStyle(
                color: Color(0xFFE7EEF7),
                fontSize: 15,
                height: 1.55,
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) =>
                        FavoriteFormPage(fruitName: fruit.name),
                  ),
                );
              },
              icon: const Icon(Icons.star_rounded),
              label: const Text('Pilih sebagai Favorit'),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoPanel extends StatelessWidget {
  const _InfoPanel({required this.fruit});

  final DevilFruit fruit;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        children: [
          _InfoRow(label: 'Type', value: fruit.type),
          const Divider(height: 20),
          _InfoRow(label: 'User', value: fruit.user),
          const Divider(height: 20),
          _InfoRow(label: 'Ringkasan', value: fruit.shortDescription),
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  const _InfoRow({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 86,
          child: Text(
            label,
            style: const TextStyle(
              color: Color(0xFF6B7684),
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
        Expanded(
          child: Text(
            value,
            style: const TextStyle(
              color: Color(0xFF1D2630),
              fontWeight: FontWeight.w700,
              height: 1.35,
            ),
          ),
        ),
      ],
    );
  }
}
