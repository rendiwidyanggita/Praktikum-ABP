package com.example.devil_fruit_catalog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
