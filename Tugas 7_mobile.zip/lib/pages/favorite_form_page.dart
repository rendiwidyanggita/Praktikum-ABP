import 'package:flutter/material.dart';

class FavoriteFormPage extends StatefulWidget {
  const FavoriteFormPage({super.key, required this.fruitName});

  final String fruitName;

  @override
  State<FavoriteFormPage> createState() => _FavoriteFormPageState();
}

class _FavoriteFormPageState extends State<FavoriteFormPage> {
  final TextEditingController _nameController = TextEditingController();
  late final TextEditingController _fruitController;
  final TextEditingController _reasonController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _fruitController = TextEditingController(text: widget.fruitName);
  }

  @override
  void dispose() {
    _nameController.dispose();
    _fruitController.dispose();
    _reasonController.dispose();
    super.dispose();
  }

  void _submitFavorite() {
    final name = _nameController.text.trim();
    final fruit = _fruitController.text.trim();
    final reason = _reasonController.text.trim();

    if (name.isEmpty || fruit.isEmpty || reason.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Harap isi semua data terlebih dahulu.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Terima kasih!'),
          content: Text(
            'Pilihan Devil Fruit favorit $name berhasil dikirim.\n\n'
            'Favorit: $fruit\n'
            'Alasan: $reason',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Form Devil Fruit Favorit')),
      body: Container(
        color: const Color(0xFF0B1D3A),
        child: ListView(
          padding: const EdgeInsets.all(18),
          children: [
            const Text(
              'Form Devil Fruit Favorit',
              style: TextStyle(
                color: Colors.white,
                fontSize: 24,
                fontWeight: FontWeight.w800,
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Isi nama dan alasan kenapa buah ini jadi pilihanmu.',
              style: TextStyle(color: Color(0xFFDDE7F0), fontSize: 14),
            ),
            const SizedBox(height: 22),
            _FieldLabel(label: 'Nama Kamu'),
            TextField(
              controller: _nameController,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                hintText: 'Masukkan nama',
                prefixIcon: Icon(Icons.person_rounded),
              ),
            ),
            const SizedBox(height: 16),
            _FieldLabel(label: 'Devil Fruit Favorit'),
            TextField(
              controller: _fruitController,
              textInputAction: TextInputAction.next,
              decoration: const InputDecoration(
                hintText: 'Nama Devil Fruit',
                prefixIcon: Icon(Icons.local_florist_rounded),
              ),
            ),
            const SizedBox(height: 16),
            _FieldLabel(label: 'Alasan Memilih'),
            TextField(
              controller: _reasonController,
              maxLines: 4,
              decoration: const InputDecoration(
                hintText: 'Tulis alasanmu',
                alignLabelWithHint: true,
                prefixIcon: Icon(Icons.edit_note_rounded),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _submitFavorite,
              icon: const Icon(Icons.send_rounded),
              label: const Text('Kirim Favorit'),
            ),
          ],
        ),
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        label,
        style: const TextStyle(
          color: Color(0xFFFFB547),
          fontSize: 14,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}
