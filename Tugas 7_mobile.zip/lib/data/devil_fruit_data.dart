import '../models/devil_fruit.dart';

const List<DevilFruit> devilFruits = [
  DevilFruit(
    name: 'Hito Hito no Mi, Model: Nika',
    type: 'Mythical Zoan',
    user: 'Monkey D. Luffy',
    image: 'assets/images/nika.png',
    shortDescription:
        'Buah legendaris dengan kekuatan tubuh karet dan kebebasan bertarung.',
    description:
        'Hito Hito no Mi, Model: Nika adalah Devil Fruit legendaris yang memberi penggunanya tubuh seperti karet serta kemampuan bertarung yang sangat bebas dan imajinatif. Dalam bentuk awakening, kekuatannya menjadi jauh lebih fleksibel dan sulit diprediksi.',
  ),
  DevilFruit(
    name: 'Gura Gura no Mi',
    type: 'Paramecia',
    user: 'Edward Newgate / Marshall D. Teach',
    image: 'assets/images/gura.png',
    shortDescription: 'Buah gempa dengan daya hancur sangat besar.',
    description:
        'Gura Gura no Mi memungkinkan penggunanya menciptakan getaran atau gempa kuat yang dapat menghancurkan area luas. Buah ini dikenal sebagai salah satu Devil Fruit dengan daya rusak terbesar di dunia One Piece.',
  ),
  DevilFruit(
    name: 'Yami Yami no Mi',
    type: 'Logia',
    user: 'Marshall D. Teach',
    image: 'assets/images/yami.png',
    shortDescription:
        'Buah kegelapan yang dapat menarik dan meniadakan kekuatan lain.',
    description:
        'Yami Yami no Mi memberikan kekuatan kegelapan yang dapat menarik objek, menyerap serangan, dan meniadakan kekuatan Devil Fruit lawan saat tersentuh. Buah ini sangat berbahaya karena dapat melawan banyak tipe kekuatan.',
  ),
  DevilFruit(
    name: 'Ope Ope no Mi',
    type: 'Paramecia',
    user: 'Trafalgar D. Water Law',
    image: 'assets/images/ope.png',
    shortDescription:
        'Buah operasi yang menciptakan ruang manipulasi bernama ROOM.',
    description:
        'Ope Ope no Mi memungkinkan penggunanya menciptakan area bernama ROOM. Di dalam area tersebut, pengguna dapat memindahkan, memotong, menukar, atau memanipulasi objek dan manusia seperti sedang melakukan operasi.',
  ),
  DevilFruit(
    name: 'Magu Magu no Mi',
    type: 'Logia',
    user: 'Sakazuki / Akainu',
    image: 'assets/images/magu.png',
    shortDescription: 'Buah magma dengan serangan panas dan destruktif.',
    description:
        'Magu Magu no Mi memberi kemampuan untuk menciptakan, mengendalikan, dan berubah menjadi magma. Kekuatan ini memiliki daya serang sangat tinggi dan cocok ditampilkan sebagai salah satu Devil Fruit paling ofensif.',
  ),
  DevilFruit(
    name: 'Pika Pika no Mi',
    type: 'Logia',
    user: 'Borsalino / Kizaru',
    image: 'assets/images/pika.png',
    shortDescription: 'Buah cahaya dengan kecepatan dan laser mematikan.',
    description:
        'Pika Pika no Mi memberi kemampuan untuk menciptakan, mengendalikan, dan berubah menjadi cahaya. Penggunanya dapat bergerak sangat cepat dan menyerang menggunakan tembakan laser.',
  ),
  DevilFruit(
    name: 'Goro Goro no Mi',
    type: 'Logia',
    user: 'Enel',
    image: 'assets/images/goro.png',
    shortDescription: 'Buah petir yang memberi kekuatan listrik besar.',
    description:
        'Goro Goro no Mi memungkinkan penggunanya menghasilkan, mengendalikan, dan berubah menjadi listrik. Buah ini sangat kuat karena memiliki serangan jarak jauh, kecepatan tinggi, dan daya hancur besar.',
  ),
  DevilFruit(
    name: 'Hie Hie no Mi',
    type: 'Logia',
    user: 'Kuzan / Aokiji',
    image: 'assets/images/hie.png',
    shortDescription: 'Buah es yang dapat membekukan area luas.',
    description:
        'Hie Hie no Mi memberi kemampuan untuk menciptakan, mengendalikan, dan berubah menjadi es. Penggunanya dapat membekukan musuh, lingkungan, bahkan permukaan laut dalam skala besar.',
  ),
  DevilFruit(
    name: 'Mera Mera no Mi',
    type: 'Logia',
    user: 'Portgas D. Ace / Sabo',
    image: 'assets/images/mera.png',
    shortDescription: 'Buah api yang ikonik dan sangat ofensif.',
    description:
        'Mera Mera no Mi memungkinkan penggunanya menciptakan, mengendalikan, dan berubah menjadi api. Buah ini terkenal karena digunakan oleh Ace dan kemudian Sabo, serta memiliki serangan api yang luas dan kuat.',
  ),
  DevilFruit(
    name: 'Uo Uo no Mi, Model: Seiryu',
    type: 'Mythical Zoan',
    user: 'Kaido',
    image: 'assets/images/seiryu.png',
    shortDescription: 'Buah naga biru dengan kekuatan fisik luar biasa.',
    description:
        'Uo Uo no Mi, Model: Seiryu memungkinkan penggunanya berubah menjadi naga biru raksasa. Kekuatan ini memberi daya tahan tinggi, kemampuan terbang, dan serangan napas penghancur.',
  ),
  DevilFruit(
    name: 'Tori Tori no Mi, Model: Phoenix',
    type: 'Mythical Zoan',
    user: 'Marco',
    image: 'assets/images/phoenix.png',
    shortDescription: 'Buah phoenix dengan regenerasi api biru.',
    description:
        'Tori Tori no Mi, Model: Phoenix memberi kemampuan berubah menjadi phoenix. Penggunanya dapat terbang dan menyembuhkan luka dengan api biru, membuatnya sangat sulit dikalahkan.',
  ),
  DevilFruit(
    name: 'Soru Soru no Mi',
    type: 'Paramecia',
    user: 'Charlotte Linlin / Big Mom',
    image: 'assets/images/soru.png',
    shortDescription: 'Buah jiwa yang dapat memberi kehidupan pada benda.',
    description:
        'Soru Soru no Mi memungkinkan penggunanya memanipulasi jiwa. Pengguna dapat mengambil sebagian umur seseorang dan memasukkan jiwa ke benda atau makhluk lain untuk menciptakan homies.',
  ),
  DevilFruit(
    name: 'Nikyu Nikyu no Mi',
    type: 'Paramecia',
    user: 'Bartholomew Kuma',
    image: 'assets/images/nikyu.png',
    shortDescription: 'Buah paw-pad yang dapat memantulkan hampir apa pun.',
    description:
        'Nikyu Nikyu no Mi memberi bantalan telapak tangan yang dapat memantulkan serangan, udara, rasa sakit, dan bahkan manusia ke lokasi yang sangat jauh. Kekuatan ini unik, fleksibel, dan sangat kuat secara defensif maupun taktis.',
  ),
  DevilFruit(
    name: 'Zushi Zushi no Mi',
    type: 'Paramecia',
    user: 'Issho / Fujitora',
    image: 'assets/images/zushi.png',
    shortDescription: 'Buah gravitasi yang dapat menarik meteor.',
    description:
        'Zushi Zushi no Mi memungkinkan penggunanya mengendalikan gravitasi. Pengguna dapat meningkatkan tekanan gravitasi, menjatuhkan objek besar, bahkan menarik meteor dari langit.',
  ),
  DevilFruit(
    name: 'Ito Ito no Mi',
    type: 'Paramecia',
    user: 'Donquixote Doflamingo',
    image: 'assets/images/ito.png',
    shortDescription:
        'Buah benang untuk mengendalikan, memotong, dan menjebak musuh.',
    description:
        'Ito Ito no Mi memungkinkan penggunanya menciptakan dan mengendalikan benang tajam. Benang ini bisa digunakan untuk menyerang, bertahan, mengendalikan tubuh orang lain, hingga membentuk sangkar besar.',
  ),
];
