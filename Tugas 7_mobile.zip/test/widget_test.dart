import 'package:devil_fruit_catalog/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  testWidgets('home page shows catalog title and first item', (tester) async {
    await tester.pumpWidget(const DevilFruitCatalogApp());

    expect(find.text('Devil Fruit Catalog'), findsOneWidget);
    expect(find.text('Hito Hito no Mi, Model: Nika'), findsOneWidget);
    expect(find.text('Lihat Detail'), findsWidgets);
  });
}
