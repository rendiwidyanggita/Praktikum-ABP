import 'package:flutter/material.dart';

import 'pages/home_page.dart';

void main() {
  runApp(const DevilFruitCatalogApp());
}

class DevilFruitCatalogApp extends StatelessWidget {
  const DevilFruitCatalogApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seaBlue = Color(0xFF0B1D3A);
    const deepBlue = Color(0xFF102A43);
    const treasureGold = Color(0xFFFFB547);

    return MaterialApp(
      title: 'Devil Fruit Catalog',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: seaBlue,
        colorScheme: ColorScheme.fromSeed(
          seedColor: treasureGold,
          primary: treasureGold,
          secondary: const Color(0xFFE85D3F),
          surface: Colors.white,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: deepBlue,
          foregroundColor: Colors.white,
          centerTitle: true,
          titleTextStyle: TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.w700,
          ),
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: treasureGold,
            foregroundColor: const Color(0xFF1B1B1B),
            minimumSize: const Size.fromHeight(48),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            textStyle: const TextStyle(fontWeight: FontWeight.w700),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: Colors.white,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: BorderSide.none,
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: treasureGold, width: 2),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}
