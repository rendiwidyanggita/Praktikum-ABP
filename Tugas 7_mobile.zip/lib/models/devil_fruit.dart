class DevilFruit {
  const DevilFruit({
    required this.name,
    required this.type,
    required this.user,
    required this.image,
    required this.shortDescription,
    required this.description,
  });

  final String name;
  final String type;
  final String user;
  final String image;
  final String shortDescription;
  final String description;
}
